Уважаемый, <?php echo e($name); ?>, благодарим за регистрацию!
Ссылка на наш <a href="<?php echo e(route('auth.register.done')."?name=$name"); ?>">сайт</a>.
<?php /**PATH C:\Users\Serker\Документы\GitHub\Web-Tech-Lab1\sardarov_lr3\resources\views/auth/register_done_mail.blade.php ENDPATH**/ ?>