<?php $__env->startSection('title'); ?>
    Успешная регистрация
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Уважаемый, <?php echo e(Request::get('name')); ?>, благодарим за регистрацию!
    Мы отправили вам на почту письмо, чтобы вы не забыли про нас.
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Serker\Документы\GitHub\Web-Tech-Lab1\sardarov_lr3\resources\views/auth/register_done.blade.php ENDPATH**/ ?>