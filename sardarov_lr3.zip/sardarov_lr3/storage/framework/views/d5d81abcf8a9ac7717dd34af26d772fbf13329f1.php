

<?php $__env->startSection('title'); ?>
    Сообщение
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>
        <?php if($message == 'register_done'): ?>
            Успешная регистрация
        <?php elseif($message == 'register_done_but_auth_error'): ?>
            Успешная регистрация, но войти не удалось.
        <?php elseif($message == 'auth_error'): ?>
            Неверный логин или пароль.

        <?php elseif($message == 'profile_updated'): ?>{
            Здрасьте. Профиль обновлён.
        }
        <?php endif; ?>
    </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Serker\Документы\GitHub\Web-Tech-Lab1\sardarov_lr3\resources\views/auth/message.blade.php ENDPATH**/ ?>
