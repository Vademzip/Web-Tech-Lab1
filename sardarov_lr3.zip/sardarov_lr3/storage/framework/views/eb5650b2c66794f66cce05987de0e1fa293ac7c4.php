
<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link href="/css/registrationAccount.css" rel="stylesheet" >
        <!-- Styles -->
        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
    <table class="header-table lock-padding">
        <td><a href="<?php echo e(route('static_page','home')); ?>">
                <div style="text-align: center;"><img src="https://www.gestion.ru/wp-content/uploads/2020/09/logo6.svg" alt=""></div>
            </a></td>
        <td class="siteName">Гестион</td>
        <td>
            <?php if(auth()->guard()->check()): ?>
                <span>
                    Здравствуйте, <?php echo e(auth()->user()->login2); ?>! <br>
                    <a href="<?php echo e(route('auth.profile')); ?>">Профиль</a>
                    <a href="<?php echo e(route('auth.logout')); ?>">Выход из аккаунта</a>
                </span>
            <?php else: ?>
                <div class="forms">
                    <form method="POST" action="<?php echo e(route('auth.login.do')); ?>" enctype="multipart/form-data">
                    <div><label for="login">Логин : </label><input id="login" name="login2" required placeholder="или почта/телефон"></div>
                    <div><label for="password">Пароль : </label><input id="password" name="password2" type="password"></div>
                    <a href="<?php echo e(route('auth.register')); ?>">Регистрация</a>
                    <button type="submit">Войти</button>
                    </form>
                </div>
            <?php endif; ?>
        </td>
    </table>

    <table class="underHeader-table lock-padding">
        <td><a href="<?php echo e(route('static_page','home')); ?>">Главная</a></td>
        <td><a href="<?php echo e(route('static_page','about-us')); ?>">История фирмы</a></td>
        <td><a href="<?php echo e(route('static_page','staff')); ?>">Сотрудники</a></td>
        <td><a href="<?php echo e(route('static_page','news')); ?>">Новости и Статьи</a></td>
        <td><a href="<?php echo e(route('static_page','registration')); ?>">Регистрация фирм</a></td>
    </table>
                <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>
<?php /**PATH C:\Users\Serker\Документы\GitHub\Web-Tech-Lab1\sardarov_lr3\resources\views/layout.blade.php ENDPATH**/ ?>