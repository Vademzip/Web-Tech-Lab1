@extends('layout')

@section('title')
    {{$title}}
@endsection

@section('content')
    {!!$content!!}
@endsection
