Уважаемый, {{$name}}, благодарим за регистрацию!
Ссылка на наш <a href="{{route('auth.register.done')."?name=$name"}}">сайт</a>.
