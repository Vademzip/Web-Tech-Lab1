@extends('layout')

@section('title')
    Профиль пользователя
@endsection

@section('content')
    <body>
    <div class="registration_wrapper">
        <h1 align = "center">Профиль пользователя</h1>
        <form method="post"  action="{{route('auth.profile.update')}}" enctype="multipart/form-data">
            <div><label for="userName"> Имя</label><input type="text" name="userName" id="userName" readonly value="{{auth()->guard()->user()->userName}}"></div>
            <div><label for="login2"> Логин</label><input type="text" name="login2" id="login2"  required value="{{auth()->guard()->user()->login2}}"></div>
            <div><label for="email"> Почта</label><input type="email" name="email" id="email" readonly value="{{auth()->guard()->user()->email}}" required></div>
            <div><label for="dateOfBirth"> Дата рождения</label><input type="date" name="dateOfBirth" readonly value="{{auth()->guard()->user()->dateOfBirth}}"  id="dateOfBirth" checked></div>
            <div><label for="phone-mask"> Номер телефона</label><input type="text" name="phoneNumber"  readonly id="phone-mask" required value="{{auth()->guard()->user()->phoneNumber}}">
            </div>
            <div class="citiesSearch">
                <div><input type="text" name="city" id="cities" placeholder="Ваш город..." readonly value="{{auth()->guard()->user()->city}}"></div>
                <ul class="list"></ul>
            </div>
            <button name="submitButton" type="submit">Обновить данные</button>
        </form>
    </div>

    <div style="color: red">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <script src="https://unpkg.com/imask"></script>
    <script src="../js/checkname.js"></script>
    </body>

    <script>
        var phoneMask = IMask(
            document.getElementById('phone-mask'), {
                mask: '+{7}(000)000-00-00'
            });

        const succsess = () =>{
            alert("Вы успешно зарегестрировались!")
        }

        // function checkPassword(form) {
        //   password1 = document.querySelector("input[name ='password']").value;
        //   password2 = document.querySelector("input[name ='passwordRewrite']").value;

        //   // If password not entered
        //   if (password1 == '')
        //     alert("Пожалуйста, введите пароль");
        //   // If confirm password not entered
        //   else if (password2 == '')
        //     alert("Пожалуйста, подтвердите ваш пароль");

        //   // If Not same return False.
        //   else if (password1 != password2) {
        //     alert("Пароль введен неправильно!")
        //     return false;
        //   }

        //   // If same return True.
        //   else {
        //     alert("Пароль был введён правильно!")
        //     return true;
        //   }

        // }
    </script>

    <script>
        let cities = [
            "Москва",
            "Санкт-Петербург",
            "Екатеринбург",
            "Уфа",
            "Омск",
            "Томск",
            "Краснодар",
            "Новосибирск",
            "Тула",
            "Калуга",
            "Ростов-На-Дону",
            "Архангельск",
            "Астрахань",
            "Хабаровск",
            "Владивосток",
            "Тюмень",
            "Сургут",
            "Сочи",
            "Элиста",
            "Махачкала",
            "Грозный",
            "Дербент",
            "Дубна",
            "Подольск",
            "Ижевск",
            "Ульяновск",
            "Самара",
            "Рязань",
            "Камчатка",
        ]

        let sortedNames = cities.sort();

        let citiesInput = document.getElementById("cities")

        if (citiesInput) {
            citiesInput.addEventListener("keyup", (e) => {
                removeElements();
                for (let i of sortedNames) {
                    if ((i.toLowerCase().startsWith(citiesInput.value.toLowerCase())) && citiesInput.value != "") {
                        let listItem = document.createElement("li")
                        listItem.classList.add("list-items");
                        listItem.style.cursor = "pointer";
                        listItem.setAttribute("onclick", "displayNames('" + i + "')");
                        let word = "<b>" + i.substring(0, citiesInput.value.length) + "</b>";
                        word += i.substring(citiesInput.value.length);
                        listItem.innerHTML = word;
                        document.querySelector(".list").appendChild(listItem);
                    }

                }
            })
        }

        function displayNames(value) {
            citiesInput.value = value;
            removeElements();
        }

        function removeElements() {
            let items = document.querySelectorAll(".list-items");
            items.forEach((item) => {
                item.remove();
            });
        }

    </script>
@endsection
