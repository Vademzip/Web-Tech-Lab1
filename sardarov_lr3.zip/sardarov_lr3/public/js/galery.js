let item1 = document.getElementsByClassName("item1");
let item2 = document.getElementsByClassName("item2");
let item3 = document.getElementsByClassName("item3");
let item4 = document.getElementsByClassName("item4");
let item5 = document.getElementsByClassName("item5");
let item6 = document.getElementsByClassName("item6");
let item7 = document.getElementsByClassName("item7");
let item8 = document.getElementsByClassName("item8");
let wrapper = document.getElementsByClassName("wrapper");
console.log(wrapper)



item1[0].addEventListener('mouseover',()=>{
    item2[0].classList.add("unactive")
    item3[0].classList.add("unactive")
    item4[0].classList.add("unactive")
    item5[0].classList.add("unactive")
    item6[0].classList.add("unactive")
    item7[0].classList.add("unactive")
    item8[0].classList.add("unactive")
})

item1[0].addEventListener('mouseout',()=>{
    item2[0].classList.remove("unactive")
    item3[0].classList.remove("unactive")
    item4[0].classList.remove("unactive")
    item5[0].classList.remove("unactive")
    item6[0].classList.remove("unactive")
    item7[0].classList.remove("unactive")
    item8[0].classList.remove("unactive")
})

item2[0].addEventListener('mouseover',()=>{
    item1[0].classList.add("unactive")
    item3[0].classList.add("unactive")
    item4[0].classList.add("unactive")
    item5[0].classList.add("unactive")
    item6[0].classList.add("unactive")
    item7[0].classList.add("unactive")
    item8[0].classList.add("unactive")
})

item2[0].addEventListener('mouseout',()=>{
    item1[0].classList.remove("unactive")
    item3[0].classList.remove("unactive")
    item4[0].classList.remove("unactive")
    item5[0].classList.remove("unactive")
    item6[0].classList.remove("unactive")
    item7[0].classList.remove("unactive")
    item8[0].classList.remove("unactive")
})


item3[0].addEventListener('mouseover',()=>{
    item2[0].classList.add("unactive")
    item1[0].classList.add("unactive")
    item4[0].classList.add("unactive")
    item5[0].classList.add("unactive")
    item6[0].classList.add("unactive")
    item7[0].classList.add("unactive")
    item8[0].classList.add("unactive")
})

item3[0].addEventListener('mouseout',()=>{
    item2[0].classList.remove("unactive")
    item1[0].classList.remove("unactive")
    item4[0].classList.remove("unactive")
    item5[0].classList.remove("unactive")
    item6[0].classList.remove("unactive")
    item7[0].classList.remove("unactive")
    item8[0].classList.remove("unactive")
})


item4[0].addEventListener('mouseover',()=>{
    item2[0].classList.add("unactive")
    item3[0].classList.add("unactive")
    item1[0].classList.add("unactive")
    item5[0].classList.add("unactive")
    item6[0].classList.add("unactive")
    item7[0].classList.add("unactive")
    item8[0].classList.add("unactive")
})

item4[0].addEventListener('mouseout',()=>{
    item2[0].classList.remove("unactive")
    item3[0].classList.remove("unactive")
    item1[0].classList.remove("unactive")
    item5[0].classList.remove("unactive")
    item6[0].classList.remove("unactive")
    item7[0].classList.remove("unactive")
    item8[0].classList.remove("unactive")
})


item5[0].addEventListener('mouseover',()=>{
    item2[0].classList.add("unactive")
    item3[0].classList.add("unactive")
    item4[0].classList.add("unactive")
    item1[0].classList.add("unactive")
    item6[0].classList.add("unactive")
    item7[0].classList.add("unactive")
    item8[0].classList.add("unactive")
})


item5[0].addEventListener('mouseout',()=>{
    item2[0].classList.remove("unactive")
    item3[0].classList.remove("unactive")
    item4[0].classList.remove("unactive")
    item1[0].classList.remove("unactive")
    item6[0].classList.remove("unactive")
    item7[0].classList.remove("unactive")
    item8[0].classList.remove("unactive")
})


item6[0].addEventListener('mouseover',()=>{
    item2[0].classList.add("unactive")
    item3[0].classList.add("unactive")
    item4[0].classList.add("unactive")
    item5[0].classList.add("unactive")
    item7[0].classList.add("unactive")
    item1[0].classList.add("unactive")
    item8[0].classList.add("unactive")
})

item6[0].addEventListener('mouseout',()=>{
    item2[0].classList.remove("unactive")
    item3[0].classList.remove("unactive")
    item4[0].classList.remove("unactive")
    item5[0].classList.remove("unactive")
    item1[0].classList.remove("unactive")
    item7[0].classList.remove("unactive")
    item8[0].classList.remove("unactive")
})


item7[0].addEventListener('mouseover',()=>{
    item2[0].classList.add("unactive")
    item3[0].classList.add("unactive")
    item4[0].classList.add("unactive")
    item5[0].classList.add("unactive")
    item6[0].classList.add("unactive")
    item1[0].classList.add("unactive")
    item8[0].classList.add("unactive")
})

item7[0].addEventListener('mouseout',()=>{
    item2[0].classList.remove("unactive")
    item3[0].classList.remove("unactive")
    item4[0].classList.remove("unactive")
    item5[0].classList.remove("unactive")
    item6[0].classList.remove("unactive")
    item1[0].classList.remove("unactive")
    item8[0].classList.remove("unactive")
})


item8[0].addEventListener('mouseover',()=>{
    item2[0].classList.add("unactive")
    item3[0].classList.add("unactive")
    item4[0].classList.add("unactive")
    item5[0].classList.add("unactive")
    item6[0].classList.add("unactive")
    item7[0].classList.add("unactive")
    item1[0].classList.add("unactive")
})

item8[0].addEventListener('mouseout',()=>{
    item2[0].classList.remove("unactive")
    item3[0].classList.remove("unactive")
    item4[0].classList.remove("unactive")
    item5[0].classList.remove("unactive")
    item6[0].classList.remove("unactive")
    item7[0].classList.remove("unactive")
    item1[0].classList.remove("unactive")
})


